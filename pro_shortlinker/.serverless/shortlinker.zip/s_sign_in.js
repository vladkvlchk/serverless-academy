
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'vladkvlchk',
  applicationName: 'shortlinker',
  appUid: 'pm3Jn27ckB1dYlVjml',
  orgUid: 'a663f1d0-3c06-4eb9-a417-f87d9cb6e599',
  deploymentUid: 'ec0bc6a1-3676-4f68-8e5d-028f77fe9f40',
  serviceName: 'shortlinker',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.1.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'shortlinker-dev-sign-in', timeout: 6 };

try {
  const userHandler = require('./build/functions/sign-in.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}