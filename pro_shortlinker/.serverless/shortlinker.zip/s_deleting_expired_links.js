
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'vladkvlchk',
  applicationName: 'shortlinker',
  appUid: 'pm3Jn27ckB1dYlVjml',
  orgUid: 'a663f1d0-3c06-4eb9-a417-f87d9cb6e599',
  deploymentUid: '63541b36-d476-4e31-9fe0-9eadda504d38',
  serviceName: 'shortlinker',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.1.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'shortlinker-dev-deleting-expired-links', timeout: 6 };

try {
  const userHandler = require('./build/functions/deleting-expired-links.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}