export type TokensType = {
    accessToken: string
    refreshToken: string
}