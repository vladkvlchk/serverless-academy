import checkEmail from "./email";
import checkPassword from "./password";
import checkActiveTime from "./active-time";
import checkLink from "./link";

export {
  checkEmail,
  checkPassword,
  checkActiveTime,
  checkLink,
};
