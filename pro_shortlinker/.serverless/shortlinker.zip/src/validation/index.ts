import checkEmail from "./email";
import checkPassword from "./password";
import checkDate from "./date";
import checkLink from "./link";

module.exports = {
    checkEmail,
    checkPassword,
    checkDate,
    checkLink
}