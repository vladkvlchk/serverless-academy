import * as checkEmail from "./email";
import checkPassword from "./password";

module.exports = {
    checkEmail,
    checkPassword
}