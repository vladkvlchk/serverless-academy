import dynamodb from "../db";

class LinkService {
  async addLink(
    original_link: string,
    expiration_time: string,
    owner_email: string
  ) {
    const chars =
      "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"; //length - 62 ( sorted by chars.split('').sort().join(''); )
    let id = ""; //this will be short path

    const data = await dynamodb.scan({ TableName: "LinksTable" }).promise();

    const all_items = data.Items.sort((itemA, itemB) => {
      if (itemA.id.length > itemB.id.length) {
        return 1;
      }
      if (itemA.id.length < itemB.id.length) {
        return -1;
      } else {
        return itemA.id > itemB.id ? 1 : -1;
      }
    });

    const last_link_id = all_items.length
      ? all_items[all_items.length - 1].id
      : ""; //last booked link id

    let flag = false; // this flag we use to know if we need to keep changing next chars (false - we need | true - we don't need)
    id = last_link_id
      .split("")
      .reverse()
      .map((char) => {
        if (flag) return char;

        const n_i = chars.indexOf(char); //0-61
        if (n_i !== chars.length - 1) flag = true; // if index is not 61(max value)

        return chars[(n_i + 1) % chars.length];
      })
      .reverse()
      .join("");

    if (!flag) {
      // adding one char like we add figure when we get 10(2 figures) after 9(1 figure), or 100(3 figures) after 99(2 figures)
      id += chars[0];
    }

    //assembling data
    const short_link = process.env.HOST + "/" + id;
    const params = {
      TableName: "LinksTable",
      Item: {
        id,
        original_link,
        short_link,
        owner_email,
        expiration_time,
      },
    };
    await dynamodb.put(params).promise();

    return params.Item;
  }

  async removeLink(link_id: string, owner_email: string): Promise<void> {
    //checking if user own the link
    const data = await dynamodb
      .get({
        TableName: "LinksTable",
        Key: {
          id: link_id,
        },
      })
      .promise();
    if (!data.Item) {
      throw new Error("Link is not found");
    }
    if (data.Item.owner_email !== owner_email) {
      throw new Error("User does't own this link");
    }

    //deleting item
    await dynamodb
      .delete({
        TableName: "Links",
        Key: {
          id: link_id,
        },
      })
      .promise();
  }

  async getLinksByEmail(email: string) {
    const data = await dynamodb
      .scan({
        TableName: "LinksTable",
        FilterExpression: "owner_email = :email",
        ExpressionAttributeValues: {
          ":email": email,
        },
      })
      .promise();
    
    return data.Items.map(item => ({
        id: item.id,
        original_link: item.original_link,
        expiration_time: item.expiration_time,
        short_link: item.short_link,
    }))
  }
}

export default new LinkService();
