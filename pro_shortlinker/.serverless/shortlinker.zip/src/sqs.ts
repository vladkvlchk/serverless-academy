import * as AWS from 'aws-sdk';

const sqs = new AWS.SQS();

export default sqs