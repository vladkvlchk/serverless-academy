
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'vladkvlchk',
  applicationName: 'shortlinker',
  appUid: 'pm3Jn27ckB1dYlVjml',
  orgUid: 'a663f1d0-3c06-4eb9-a417-f87d9cb6e599',
  deploymentUid: 'c4808b1c-1948-4c8f-9b94-cc59042d82b1',
  serviceName: 'shortlinker',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.1.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'shortlinker-dev-deactivate-link', timeout: 6 };

try {
  const userHandler = require('./build/functions/http/link/deactivate-link.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}