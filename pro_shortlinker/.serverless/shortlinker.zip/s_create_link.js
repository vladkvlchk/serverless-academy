
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'vladkvlchk',
  applicationName: 'shortlinker',
  appUid: 'pm3Jn27ckB1dYlVjml',
  orgUid: 'a663f1d0-3c06-4eb9-a417-f87d9cb6e599',
  deploymentUid: '23c0aec2-8bd3-4a36-932f-92692a7326d8',
  serviceName: 'shortlinker',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.1.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'shortlinker-dev-create-link', timeout: 6 };

try {
  const userHandler = require('./build/functions/create-link.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}